//
//  TestCheckListViewController.m
//  Air Health Assistant
//
//  Created by xu da on 14-7-21.
//  Copyright (c) 2014年 xu da. All rights reserved.
//

#import "TestCheckListViewController.h"

@interface TestCheckListViewController ()

@end

@implementation TestCheckListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
