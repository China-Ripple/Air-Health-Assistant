//
//  NSDetailEntity.m
//  Air Health Assistant
//
//  Created by xu da on 14-7-21.
//  Copyright (c) 2014年 xu da. All rights reserved.
//

#import "XDetailEntity.h"

@implementation XDetailEntity
@synthesize image;
@synthesize image2;
@synthesize title;
@synthesize content;
@synthesize rowHeightP;
@synthesize rowHeightL;

@end
