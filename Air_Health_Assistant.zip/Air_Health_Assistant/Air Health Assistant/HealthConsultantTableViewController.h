//
//  HealthConsultantTableViewController.h
//  Air Health Assistant
//
//  Created by xu da on 14-7-23.
//  Copyright (c) 2014年 xu da. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HealthConsultantTableViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property NSMutableArray *detailArray;
@end
