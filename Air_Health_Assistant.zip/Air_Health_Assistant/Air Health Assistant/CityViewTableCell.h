//
//  CityViewTableCell.h
//  Air Health Assistant
//
//  Created by xu da on 14-6-17.
//  Copyright (c) 2014年 xu da. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CityViewTableCell : UITableViewCell
@property NSString *cityCode;
//@property NSString *cityText;
@end
