//
//  NSDetailEntity.h
//  Air Health Assistant
//
//  Created by xu da on 14-7-21.
//  Copyright (c) 2014年 xu da. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XDetailEntity : NSObject

@property NSString *image;
@property NSString *image2;
@property NSString *title;
@property NSString *content;
@property int rowHeightP;
@property int rowHeightL;

@end
