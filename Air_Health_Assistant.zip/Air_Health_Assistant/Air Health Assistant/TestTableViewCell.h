//
//  TestTableViewCell.h
//  Air Health Assistant
//
//  Created by xu da on 14-7-19.
//  Copyright (c) 2014年 xu da. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestTableViewCell : UITableViewCell
- (void)initValue:(NSString *)textStr :(int)width :(int)height;

@end
