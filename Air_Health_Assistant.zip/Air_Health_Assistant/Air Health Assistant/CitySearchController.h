//
//  CitySearchController.h
//  Air Health Assistant
//
//  Created by 钟其鸿 on 15/7/30.
//  Copyright (c) 2015年 xu da. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CitySearchController : UIViewController{

    NSArray *data;
    NSArray *filterData;
    UISearchDisplayController *searchDisplayController;
}
@end
