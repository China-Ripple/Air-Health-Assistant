//
//  MyResultsViewController.h
//  SearchController
//
//  Created by 曦炽 朱 on 14/10/27.
//  Copyright (c) 2014年 mirroon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyResultsViewController : UIViewController <UISearchResultsUpdating>

@end
