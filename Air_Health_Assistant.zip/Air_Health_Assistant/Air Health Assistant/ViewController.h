//
//  ViewController.h
//  Air Health Assistant
//
//  Created by xu da on 14-5-5.
//  Copyright (c) 2014年 xu da. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

+ (ViewController *)sharedInstance;

@end
