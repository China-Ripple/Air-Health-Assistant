//
//  XSlelectBar.m
//  Air Health Assistant
//
//  Created by xu da on 14-5-7.
//  Copyright (c) 2014年 xu da. All rights reserved.
//

#import "XSlelectBar.h"

@interface XSlelectBar ()

@end

@implementation XSlelectBar

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
