//
//  MMLocationManager.h
//  MMLocationManager
//
//  Created by Chen Yaoqiang on 13-12-24.
//  Copyright (c) 2013年 Chen Yaoqiang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import "XBody.h"

#define  MMLastLongitude @"MMLastLongitude"
#define  MMLastLatitude  @"MMLastLatitude"
#define  MMLastProvince  @"MMLastProvince"
#define  MMLastCity      @"MMLastCity"
#define  MMLastAddress   @"MMLastAddress"

typedef void (^LocationBlock)(CLLocationCoordinate2D locationCorrrdinate);
typedef void (^LocationErrorBlock) (NSError *error);
typedef void(^NSStringBlock)(NSString *cityString);
typedef void(^NSStringBlock)(NSString *provinceString);
typedef void(^NSStringBlock)(NSString *addressString);

@interface MMLocationManager : NSObject<MKMapViewDelegate>
@property id <CityDelegate> cityDelegate;

@property(nonatomic,strong) MKMapView *mapView;
@property (nonatomic) CLLocationCoordinate2D lastCoordinate;
@property(nonatomic,strong)NSString *lastCity;
@property(nonatomic,strong)NSString *lastProvince;
@property (nonatomic,strong) NSString *lastAddress;

@property(nonatomic,assign)float latitude;
@property(nonatomic,assign)float longitude;

+ (MMLocationManager *)shareLocation;

/**
 *  获取坐标
 *
 *  @param locaiontBlock locaiontBlock description
 */
- (void) getLocationCoordinate:(LocationBlock) locaiontBlock ;

/**
 *  获取坐标和地址
 *
 *  @param locaiontBlock locaiontBlock description
 *  @param addressBlock  addressBlock description
 */
- (void) getLocationCoordinate:(LocationBlock) locaiontBlock  withAddress:(NSStringBlock) addressBlock;

/**
 *  获取地址
 *
 *  @param addressBlock addressBlock description
 */
- (void) getAddress:(NSStringBlock)addressBlock;

/**
 *  获取城市
 *
 *  @param cityBlock cityBlock description
 *  @param provinceBlock provinceBlock description
 */
- (void) getCity:(NSStringBlock)cityBlock province:(NSStringBlock)provinceBlock;

/**
 *  获取城市和定位失败
 *
 *  @param cityBlock  cityBlock description
 *  @param errorBlock errorBlock description
 */
- (void) getCity:(NSStringBlock)cityBlock error:(LocationErrorBlock) errorBlock;
/**
 *  对城市信息处理
 *
 */

- (void)gpsLocateCity;
/**
 *
 *  通过手写名字找到一堆城市列表
 *
*/

-(NSDictionary*)getCitys:(NSString*)city;

@end
