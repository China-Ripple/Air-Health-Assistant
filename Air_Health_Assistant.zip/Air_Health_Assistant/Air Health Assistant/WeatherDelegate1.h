//
//  WeatherDelegate1.h
//  Air Health Assistant
//
//  Created by xu da on 14-6-10.
//  Copyright (c) 2014年 xu da. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeatherDelegate1 : UIResponder

@end
